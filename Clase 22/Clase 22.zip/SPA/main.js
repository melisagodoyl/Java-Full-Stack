let app = new Vue ({
	el: "#app",
	data: {
		vista: "home",
	},
})